package com.URBX.URBX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrbxApplicationTests {

	@Test
	void contextLoads() {
	}

}
